package org.xinyu.com.mq.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;
import org.springframework.util.StringUtils;

public class MQConsumer {
    protected final Logger LOG = LoggerFactory.getLogger(MQConsumer.class);
    ContainerProperties containerProperties;

    DefaultKafkaConsumerFactory consumerFactory;

    KafkaMessageListenerContainer kafkaMessageListenerContainer;

    org.xinyu.com.mq.kafka.AwareRebalanceListener consumerAwareRebalanceListener;

    public MQConsumer(java.util.HashMap consumerProperties, String topic, AbstractConsumerHandler consumerHandler, Boolean isOnece, Boolean isMANUAL){

        this.consumerFactory = new DefaultKafkaConsumerFactory(consumerProperties);

        if( this.containerProperties == null ) {
            this.containerProperties = new ContainerProperties(topic);
        }

        if(isOnece) consumerHandler.setMQConsumer(this);
        this.containerProperties.setMessageListener(consumerHandler);

        if(isMANUAL) {
            this.containerProperties.setAckMode(org.springframework.kafka.listener.ContainerProperties.AckMode.MANUAL);

            if (this.consumerAwareRebalanceListener == null) {
                this.containerProperties.setConsumerRebalanceListener(consumerAwareRebalanceListener);
            }
        }

        if(this.kafkaMessageListenerContainer == null)
            this.kafkaMessageListenerContainer = new KafkaMessageListenerContainer(consumerFactory, containerProperties);
    }

    public void doStart() {
        this.kafkaMessageListenerContainer.start();
    }

    public void doStop() {
        this.kafkaMessageListenerContainer.stop(new Runnable() {
            @Override
            public void run() {
                LOG.info("doStop()");
            }
        });
    }
}
